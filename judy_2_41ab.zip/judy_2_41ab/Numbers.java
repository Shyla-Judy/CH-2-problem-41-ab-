package problem41ab;
public class Numbers{
    // Shyla Judy problem28
    //I did not copy code from other people or sources other than our CIS-221 textbook
    //I did not use any AI software to help write code
    public static void main(String[] args) {
        int sum = 0;
        int count = 0;
        LLNode<Integer> numbers = new LLNode<Integer>(1);
        LLNode<Integer> currNode = numbers;

        LLNode<Integer> newNode1 = new LLNode<Integer>(10);
        numbers. setLink(newNode1);

        LLNode<Integer> newNode2 = new LLNode<Integer>(20);
        newNode1. setLink(newNode2);

        LLNode<Integer> newNode3 = new LLNode<Integer>(30);
        newNode2. setLink(newNode3);

        while(currNode!= null){
            sum += currNode.getInfo();
            currNode = currNode.getLink();
            count += 1;
        }

        System.out.println("Sum:" + sum + "  Length:" + count);


    }

    

}